<h1>FelixTV - Kodi Video Addon</h1>
<p>
<a href="https://www.xbmc-kodi.cz/prispevek-felixtv-plugin">Forum</a>
<img src="http://saros.wz.cz/repo/plugin.video.felixtv/scr1.png" style="max-width:100%;" width="960" height="540">
<img src="http://saros.wz.cz/repo/plugin.video.felixtv/scr2.png" style="max-width:100%;" width="960" height="540">
</p>