# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib import urlencode, quote, unquote
from urlparse import parse_qsl, urlparse
from urllib2 import urlopen, Request
import re
import os
import json
import unicodedata


reload(sys)
sys.setdefaultencoding('utf-8')


_url = sys.argv[0]
_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.felixtv')


def encode(input):
    return unicodedata.normalize('NFKD', input).encode('ASCII', 'ignore') 



def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def tmdb(name, year, type):
    gid = {28: "Akční", 12: "Dobrodružný", 16: "Animovaný", 35: "Komedie", 80: "Krimi", 99: "Dokumentární", 18: "Drama", 10751: "Rodinný", 14: "Fantasy", 36: "Historický", 27: "Horor", 10402: "Hudební", 9648: "Mysteriózní", 10749: "Romantický", 878: "Vědeckofantastický", 10770: "Televizní film", 53: "Thriller", 10752: "Válečný", 37: "Western", 10759: "Action & Adventure", 10751: "Rodinný", 10762: "Kids", 9648: "Mysteriózní", 10763: "News", 10764: "Reality", 10765: "Sci-Fi & Fantasy", 10766: "Soap", 10767: "Talk", 10768: "War & Politics"}
    db = {}
    url = urlopen("https://api.themoviedb.org/3/search/" + type + "?api_key=1f0150a5f78d4adc2407911989fdb66c&query=" + quote(name) + "&year=" + year + "&language=cs-Cs").read()
    res = json.loads(url)
    if res["total_results"] == 0:
        db["plot"] = ""
        db["genre"] = ""
        db["rating"] = ""
        db["fanart"] = ""
        db["thumb"] = "http://felixtv.wz.cz/movies/thumb.png"
        db["id"] = ""
        return db
    gl = []
    for g in res["results"][0]["genre_ids"]:
        gl.append(gid[g])
    db["genre"] = " / ".join(gl)
    db["id"] = str(res["results"][0]["id"])
    db["rating"] = str(res["results"][0]["vote_average"])[:3]
    try:
        db["fanart"] = "https://image.tmdb.org/t/p/w1280" + res["results"][0]["backdrop_path"]
    except:
        db["fanart"] = ""
    try:
        db["thumb"] = "http://image.tmdb.org/t/p/w342" + res["results"][0]["poster_path"]
    except:
        db["thumb"] = ""
    if res["results"][0]["overview"] == "":
        url1 = urlopen("https://api.themoviedb.org/3/search/" + type + "?api_key=1f0150a5f78d4adc2407911989fdb66c&query=" + quote(name) + "&year=" + year + "&language=en-En").read()
        res1 = json.loads(url1)
        db["plot"] = res1["results"][0]["overview"].encode("utf-8")
    else:
        db["plot"] = res["results"][0]["overview"].encode("utf-8")
    return db


def convert_size(number_of_bytes):
    if number_of_bytes < 0:
        raise ValueError("!!! number_of_bytes can't be smaller than 0 !!!")
    step_to_greater_unit = 1024.
    number_of_bytes = float(number_of_bytes)
    unit = 'bytes'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'KB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'MB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'GB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'TB'
    precision = 1
    number_of_bytes = round(number_of_bytes, precision)
    return str(number_of_bytes) + ' ' + unit


def download_video(link, name):
    if addon.getSetting("download") == "" or not os.path.exists(addon.getSetting("download")):
        xbmcgui.Dialog().notification("FelixTV","Nastavte složku pro stahování", xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    html = urlopen(link).read()
    src=re.findall('src="http://s.felixtv.cz/web_stream.php?(.*?)>',str(html))
    stream=re.findall('q=(.*?)"',str(src))[0]
    dialog = xbmcgui.DialogProgress()
    u = urlopen("http://s.felixtv.cz/web_stream.php?q=" + stream)
    f = open(addon.getSetting("download") + name + ".mp4", "wb")
    meta = u.info()
    file_size = int(meta.getheaders("Content-Length")[0])
    dialog.create("FelixTV","Stahování...")
    file_size_dl = 0
    block_sz = 4096
    canceled = False
    while True:
        if dialog.iscanceled():
            canceled = True
            break
        buffer = u.read(block_sz)
        if not buffer: break
        file_size_dl += len(buffer)
        f.write(buffer)
        status = r"%3.2f%%" % (file_size_dl * 100. / file_size)
        status = status + chr(8)*(len(status)+1)
        dialog.update(file_size_dl * 100 / file_size, "Staženo:  " + status + " z " + convert_size(file_size), "", name + ".mp4")
    f.close()
    dialog.close()
    if canceled == False:
        dialog = xbmcgui.Dialog()
        dialog.ok('FelixTV', 'Soubor stažen', '', name + ".mp4")
    else:
        os.remove(addon.getSetting("download") + name + ".mp4")


def play_video(link):
    html = urlopen(link).read()
    src=re.findall('src="http://s.felixtv.cz/web_stream.php?(.*?)>',str(html), re.DOTALL)
    if len(src) > 1 and addon.getSetting("lang") == "0":
        stream=re.findall('q=(.*?)"',str(src))
        lang=re.findall('title="(.*?)"',str(src))
        lang = [x.encode().decode('unicode-escape').encode('latin1').decode('utf-8') for x in lang]
        choose = xbmcgui.Dialog().select("Zvolte jazyk", lang)
        if choose == -1: return
        listitem = xbmcgui.ListItem(path="http://s.felixtv.cz/web_stream.php?q=" + stream[choose])
        if lang[choose] != "Čeština":
            try:
                sub=re.findall('CAPTIONS_DB/(.*?).vtt',str(html))
                if sub != []:
                    sub_url = []
                    if len(sub) == 2:
                        sub_url = "https://felixtv.cz/CAPTIONS_DB/" + quote(sub[1]) + ".vtt"
                    else:
                        sub_url = "https://felixtv.cz/CAPTIONS_DB/" + quote(sub[0]) + ".vtt"
                    listitem.setSubtitles([sub_url])
            except:
                pass
    else:
        stream=re.findall('q=(.*?)"',str(src))[0]
        listitem = xbmcgui.ListItem(path="http://s.felixtv.cz/web_stream.php?q=" + stream)
        try:
            sub=re.findall('CAPTIONS_DB/(.*?).vtt',str(html))
            if sub != []:
                sub_url = []
                if len(sub) == 2:
                    sub_url = "https://felixtv.cz/CAPTIONS_DB/" + quote(sub[1]) + ".vtt"
                else:
                    sub_url = "https://felixtv.cz/CAPTIONS_DB/" + quote(sub[0]) + ".vtt"
                listitem.setSubtitles([sub_url])
        except:
            pass
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def list_episodes(link, id, thumb):
    html = urlopen(link).read()
    name_list = []
    soup=re.findall('/' + id + '(.*?)/a>',str(html), re.DOTALL)
    soup1=re.findall('</span>(.*?)<',str(soup))
    soup2=re.findall('/' + id + '(.*?)"',str(html), re.DOTALL)
    for n in range(0, len(soup1)):
        name_list.append((soup1[n], (link).replace(".html","/") + id + soup2[n]))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))
        list_item.setInfo('video', {'mediatype' : 'episode', 'title': category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8')})
        list_item.setArt({'thumb': thumb, 'icon': thumb})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', link = category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)


def list_series(link, thumb):
    html = urlopen(link).read()
    name_list = []
    soup=re.findall('<a data-toggle="tab" href="#s(.*?)</li>',str(html))
    for n in range(0, len(soup)):
        name_list.append((re.findall('>(.*?)</a>',str(soup))[n], re.findall('-(.*?)"',str(soup))[n]))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))
        list_item.setArt({'thumb': thumb, 'icon': thumb})
        url = get_url(action='listing_episodes', link =link, id = category[1], thumb = thumb)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_all_serials(link):
    if link == "0":
        url = "https://felixtv.cz/tvseries/home"
    else:
        url = "https://felixtv.cz/tvseries/home/" + link + ".html"
    link = str(int(link) + 24)
    html = urlopen(url).read()
    name_list = []
    np = re.findall('<ul class ="pagination"(.*?)</ul>',str(html))
    lp = re.findall('rel="(.*?)"',str(np))
    soup=re.findall('<div class="movie-img">(.*?)class="ico-play ico-play-sm">',str(html))
    for n in range(0, len(soup)):
        lang = re.findall('<div class="overlay-div"></div>(.*?)<div class="movie-title"',str(html), re.DOTALL)[n]
        try:
            lang = re.findall('src="https://felixtv.cz/assets/front_end/images/(.*?).png',str(lang), re.DOTALL)[1].replace("cs", " - CZ").replace("CZ-cc", "EN").replace("hd", "")
        except:
            lang = ""
        name_list.append(((re.findall('alt="(.*?)"> <a',str(soup))[n] + lang + " (" + re.findall('class="video_quality"><span class="label label-primary">(.*?)</span>',str(html))[n] + ")").encode().decode('unicode-escape').encode('latin1').decode('utf-8'), re.findall('href="(.*?)"',str(soup))[n], "series", re.findall('src="(.*?)"',str(soup))[n]))
    if "next" in lp:
        name_list.append(("Další", link, "next", "DefaultAddonContextItem.png"))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': category[3], 'icon': category[3]})
        url = get_url(action='listing_series', link = category[1], mode = category[2], thumb = category[3])
        if category[0] != "Další":
            list_item.setInfo('video', {'mediatype' : 'tvshow', 'title': category[0]})
            list_item.addContextMenuItems([('Uložit seriál do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library_series",name = category[0], url = category[1])))])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_new_best_serials(link):
    html = urlopen("https://felixtv.cz/").read()
    name_list = []
    if link == "0":
        soup=re.findall('<!-- New TV Series -->(.*?)<!-- End New TV Series -->',str(html),re.DOTALL)
    else:
        soup=re.findall('<!-- Latest TV Series -->(.*?)<!-- End Latest TV Series -->',str(html),re.DOTALL)
    ltitle = re.findall('<b>(.*?)</b>',str(soup),re.DOTALL)
    for n in range(0, len(ltitle)):
        title = re.findall('<b>(.*?)</b>',str(soup),re.DOTALL)[n]
        try:
            l = re.findall('<div class="overlay-div"></div>(.*?)<div class="movie-title"',str(soup), re.DOTALL)[n]
            l = re.findall('src="https://felixtv.cz/assets/front_end/images/(.*?).png"',str(l), re.DOTALL)[1]
            if l == "cs-cc":
                lang = " -EN"
            elif l == "cs":
                lang = " -CZ"
            else:
                lang = ""
        except:
            lang = ""
        year = re.findall('class="video_quality"><span class="label label-primary">(.*?)</span>',str(soup))[n]
        link = re.findall('<h1><a href="(.*?)"',str(soup))[n]
        meta = tmdb(encode(title.encode().decode('unicode-escape').encode('latin1').decode('utf-8')), year, "tv")
        name_list.append((title + lang + " (" + year + ")", "", meta, link, year))
    xbmcplugin.setContent(_handle, 'tvshows')
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))
        list_item.setInfo('video', {'mediatype' : 'tvshow', 'title': category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'), "year": category[4], "genre": category[2]["genre"], "plot": category[2]["plot"], "rating": category[2]["rating"]})
        list_item.setArt({'thumb': category[2]['thumb'], 'icon': category[2]['thumb'], 'fanart': category[2]['fanart']})
        url = get_url(action='listing_series', link = category[3], mode = "series", thumb = category[2]['thumb'])
        if category[2]["id"] != "":
            list_item.addContextMenuItems([('Přehrát trailer','XBMC.RunPlugin({})'.format(get_url(action = "trailer",yt_id = category[2]["id"], type = "tv"))), ('Uložit seriál do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library_series",name = category[0], url = category[3])))])
        else:
            list_item.addContextMenuItems([('Uložit seriál do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library_series",name = category[0], url = category[3])))])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_menu_serials():
    name_list = [("Nově přidané", 'listing_new_best_serials', "0", "DefaultRecentlyAddedEpisodes.png"), ("Nejvíce sledované", 'listing_new_best_serials', "1", "DefaultTVShows.png"),("Všechny", 'listing_all_serials', "0", "DefaultTVShows.png")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': category[3], 'icon': category[3]})
        url = get_url(action=category[1], link = category[2], mode= "home")
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_all_movies(ln0, ln1):
    html = json.loads(urlopen("http://felixtv.wz.cz/movies/" + ln0 + ".txt").read())
    name_list = []
    for n in html:
        name_list.append((n[0] + n[1] + " (" + n[2] + ")", n[2], n[3], n[4]))
    try:
        req = urlopen("http://felixtv.wz.cz/movies/" + str(int(ln0) + 1) + ".txt")
        if req.code==200:
            name_list.append(("Další", "", {"plot": "", "thumb": "DefaultAddonContextItem.png", "rating": "", "fanart": "", "genre": "", "id": ""}, ""))
    except:
        pass
    xbmcplugin.setContent(_handle, 'movies')
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'mediatype' : 'movie', 'title': category[0], "year": category[1], "genre": category[2]["genre"], "plot": category[2]["plot"], "rating": category[2]["rating"]})
        if category[0] != "Další":
            list_item.setArt({'thumb': category[2]["thumb"], 'icon': category[2]["thumb"], 'fanart': category[2]['fanart']})
            list_item.setProperty('IsPlayable', 'true')
            if category[2]["id"] != "":
                list_item.addContextMenuItems([('Přehrát trailer','XBMC.RunPlugin({})'.format(get_url(action = "trailer",yt_id = category[2]["id"], type = "movie"))), ('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[3]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[3])))])
            else:
                list_item.addContextMenuItems([('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[3]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[3])))])
            url = get_url(action='play', link = category[3])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
        else:
            list_item.setArt({'thumb': category[2]["thumb"], 'icon': category[2]["thumb"]})
            url = get_url(action='listing_all_movies', link = str(int(ln0) + 1), link1 = ln1)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_new_best_movies(link):
    html = urlopen("https://felixtv.cz/").read()
    name_list = []
    if link == "0":
        soup=re.findall('<!-- Upcomming Movies -->(.*?)<!-- End Upcomming Movies -->',str(html),re.DOTALL)
    else:
        soup=re.findall('<!-- Latest Movies -->(.*?)<!-- End Latest Movies -->',str(html),re.DOTALL)
    ltitle = re.findall('<b>(.*?)</b>',str(soup),re.DOTALL)
    for n in range(0, len(ltitle)):
        title = re.findall('<b>(.*?)</b>',str(soup),re.DOTALL)[n]
        try:
            l = re.findall('<div class="overlay-div"></div>(.*?)<div class="movie-title"',str(soup), re.DOTALL)[n]
            l = re.findall('src="https://felixtv.cz/assets/front_end/images/(.*?).png"',str(l), re.DOTALL)[1]
            if l == "cs-cc":
                lang = " -EN"
            elif l == "cs":
                lang = " -CZ"
            else:
                lang = ""
        except:
            lang = ""
        year = re.findall('class="video_quality"><span class="label label-primary">(.*?)</span>',str(soup))[n]
        link = re.findall('<h1><a href="(.*?)"',str(soup))[n]
        meta = tmdb(encode(title.encode().decode('unicode-escape').encode('latin1').decode('utf-8')), year, "movie")
        name_list.append((title + lang + " (" + year + ")", "", meta, link, year))
    xbmcplugin.setContent(_handle, 'movies')
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))
        list_item.setInfo('video', {'mediatype' : 'movie', 'title': category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'), "year": category[4], "genre": category[2]["genre"], "plot": category[2]["plot"], "rating": category[2]["rating"]})
        list_item.setArt({'thumb': category[2]['thumb'], 'icon': category[2]['thumb'], 'fanart': category[2]['fanart']})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', link = category[3])
        if category[2]["id"] != "":
            list_item.addContextMenuItems([('Přehrát trailer','XBMC.RunPlugin({})'.format(get_url(action = "trailer",yt_id = category[2]["id"], type = "movie"))), ('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[3]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[3])))])
        else:
            list_item.addContextMenuItems([('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[3]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[3])))])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)


def list_menu_movies():
    name_list = [("Nově přidané", 'listing_new_best_movies', "DefaultRecentlyAddedMovies.png", "0", ""), ("Nejvíce sledované", 'listing_new_best_movies', "DefaultMovies.png", "1", ""), ("Všechny", 'listing_all_movies', "DefaultMovies.png", "0", "20")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': category[2], 'icon': category[2]})
        url = get_url(action=category[1], link = category[3], link1 = category[4])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_genres(link, page):
    p = int(page)
    name_list = []
    while True:
        html = urlopen(link + str(p)).read()
        soup=re.findall('<div class="movie-img">(.*?)class="ico-play ico-play-sm">',str(html))
        for n in range(0, len(soup)):
            title = re.findall('alt="(.*?)"> <a',str(soup))[n]
            lang = re.findall('<div class="overlay-div"></div>(.*?)<div class="movie-title"',str(html), re.DOTALL)[n]
            try:
                lang = re.findall('src="https://felixtv.cz/assets/front_end/images/(.*?).png',str(lang), re.DOTALL)[1].replace("cs", " - CZ").replace("CZ-cc", "EN").replace("hd", "")
            except:
                lang = ""
            year = re.findall('class="video_quality"><span class="label label-primary">(.*?)</span>',str(html))[n]
            thumb = re.findall('src="(.*?)"',str(soup))[n]
            linkm = re.findall('href="(.*?)"',str(soup))[n]
            parts = urlparse(linkm).path[1:].split('/')[0]
            if parts == "watch":
                type = "movie"
            else:
                type = "tv"
            name_list.append(((title + lang + " (" + year + ")").encode().decode('unicode-escape').encode('latin1').decode('utf-8'), thumb, linkm, type))
        p = p + 24
        if p == int(page) + 384: break
    page = str(p)
    if len(name_list) == 384:
        name_list.append(("Další", "DefaultAddonContextItem.png", link, "next"))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': category[1], 'icon': category[1]})
        if category[3] == "movie":
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': category[0]})
            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', link = category[2])
            list_item.addContextMenuItems([('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[2]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[2])))])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
        elif category[3] == "tv":
            list_item.setInfo('video', {'mediatype' : 'tvshow', 'title': category[0]})
            url = get_url(action='listing_series', link = category[2], mode = "series", thumb = category[1])
            list_item.addContextMenuItems([('Uložit seriál do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library_series",name = category[0], url = category[2])))])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
        else:
            url = get_url(action='listing_genres', link = category[2], page = page)
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_menu_genres():
    genres=[("Akční", "https://felixtv.cz/genre/akcni/", "0"), ("Animované", "https://felixtv.cz/genre/animovane/", "0"), ("Dobrodružné", "https://felixtv.cz/genre/dobrodruzne/", "0"), ("Dokumentární", "https://felixtv.cz/genre/dokumentarni/", "0"), ("Drama", "https://felixtv.cz/genre/drama/", "0"), ("Erotické", "https://felixtv.cz/genre/eroticke/", "0"), ("Fantasy", "https://felixtv.cz/genre/fantasy/", "0"), ("Horror", "https://felixtv.cz/genre/horror/", "0"), ("Hudební", "https://felixtv.cz/genre/hudebni/", "0"), ("Komedie", "https://felixtv.cz/genre/komedie/", "0"), ("Krimi", "https://felixtv.cz/genre/krimi/", "0"), ("Mysteriózní", "https://felixtv.cz/genre/mystery/", "0"), ("Rodinné", "https://felixtv.cz/genre/rodinne/", "0"), ("Sci-Fi", "https://felixtv.cz/genre/sci-fi/", "0"), ("Thriller", "https://felixtv.cz/genre/thriller/", "0"), ("Válečné", "https://felixtv.cz/genre/valecne/", "0"), ("Western", "https://felixtv.cz/genre/western/", "0"), ("Životopisné", "https://felixtv.cz/genre/zivotopisne/", "0")]
    for category in genres:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': "DefaultVideoPlaylists.png", 'icon': "DefaultVideoPlaylists.png"})
        url = get_url(action='listing_genres',link=category[1], page = category[2])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def search():
    kb = xbmc.Keyboard('', 'Zadejte název filmu nebo seriálu')
    kb.doModal()
    if not kb.isConfirmed(): 
        return
    query = kb.getText()
    data = urlencode({"search": query}).encode()
    req = Request('https://felixtv.cz/search/', data)
    html = urlopen(req).read()
    name_list = []
    soup=re.findall('<div class="movie-img">(.*?)class="ico-play ico-play-sm">',str(html))
    for n in range(0, len(soup)):
        title = re.findall('alt="(.*?)"> <a',str(soup))[n]
        lang = re.findall('<div class="overlay-div"></div>(.*?)<div class="movie-title"',str(html), re.DOTALL)[n]
        try:
            lang = re.findall('src="https://felixtv.cz/assets/front_end/images/(.*?).png',str(lang), re.DOTALL)[1].replace("cs", " - CZ").replace("CZ-cc", "EN").replace("hd", "")
        except:
            lang = ""
        year = re.findall('class="video_quality"><span class="label label-primary">(.*?)</span>',str(html))[n]
        thumb = re.findall('src="(.*?)"',str(soup))[n]
        link = re.findall('href="(.*?)"',str(soup))[n]
        parts = urlparse(link).path[1:].split('/')[0]
        if parts == "watch":
            type = "movie"
        else:
            type = "tv"
        meta = tmdb(encode(title.encode().decode('unicode-escape').encode('latin1').decode('utf-8')), year, type)
        name_list.append((title + lang + " (" + year + ")", thumb, meta, link, year))
    xbmcplugin.setContent(_handle, 'videos')
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))
        parts = urlparse(category[3]).path[1:].split('/')[0]
        if parts == "watch":
            list_item.setInfo('video', {'mediatype' : 'movie', 'title': category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'), "year": category[4], "genre": category[2]["genre"], "plot": category[2]["plot"], "rating": category[2]["rating"]})
            list_item.setArt({'thumb': category[1], 'icon': category[1], 'fanart': category[2]['fanart']})
            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='play', link = category[3])
            if category[2]["id"] != "":
                list_item.addContextMenuItems([('Přehrát trailer','XBMC.RunPlugin({})'.format(get_url(action = "trailer",yt_id = category[2]["id"], type = "movie"))), ('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[3]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[3])))])
            else:
                list_item.addContextMenuItems([('Uložit film do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library",name = category[0], url = category[3]))), ('Stáhnout','XBMC.RunPlugin({})'.format(get_url(action = "download",name = category[0], url = category[3])))])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
        else:
            list_item.setInfo('video', {'mediatype' : 'tvshow', 'title': category[0].encode().decode('unicode-escape').encode('latin1').decode('utf-8'), "year": category[4], "genre": category[2]["genre"], "plot": category[2]["plot"], "rating": category[2]["rating"]})
            list_item.setArt({'thumb': category[1], 'icon': category[1], 'fanart': category[2]['fanart']})
            url = get_url(action='listing_series', link = category[3], mode = "series", thumb = category[2]["thumb"])
            if category[2]["id"] != "":
                list_item.addContextMenuItems([('Přehrát trailer','XBMC.RunPlugin({})'.format(get_url(action = "trailer",yt_id = category[2]["id"], type = "tv"))), ('Uložit seriál do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library_series",name = category[0], url = category[3])))])
            else:
                list_item.addContextMenuItems([('Uložit seriál do knihovny','XBMC.RunPlugin({})'.format(get_url(action = "library_series",name = category[0], url = category[3])))])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_years():
    html = urlopen('https://felixtv.cz/year/').read()
    years=re.findall('<a class="btn btn-lg btn-success" href="(.*?)"',str(html))
    for category in years:
        list_item = xbmcgui.ListItem(label=category[-9:-5])
        url = get_url(action='listing_genres',link=category.replace(".html", "/"), page = "0")
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_menu():
    name_list = [("Filmy", 'listing_movies', "DefaultMovies.png"),("Seriály", 'listing_menu_serials', "DefaultTVShows.png"), ("Žánr", 'listing_menu_genres', "DefaultVideoPlaylists.png"), ("Rok", 'listing_years', "DefaultVideoPlaylists.png"), ("Hledat", 'listing_search', "DefaultAddonsSearch.png")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': category[2], 'icon': category[2]})
        url = get_url(action=category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params["action"] == "listing_movies":
            list_menu_movies()
        elif params["action"] == "listing_new_best_movies":
            list_new_best_movies(params['link'])
        elif params["action"] == "listing_all_movies":
            list_all_movies(params['link'], params['link1'])
        elif params["action"] == "listing_menu_serials":
            list_menu_serials()
        elif params["action"] == "listing_new_best_serials":
            list_new_best_serials(params['link'])
        elif params["action"] == "listing_all_serials":
            list_all_serials(params['link'])
        elif params["action"] == "listing_series":
            if params["mode"] == "next":
                list_all_serials(params['link'])
            elif params["mode"] == "series":
                list_series(params['link'], params['thumb'])
        elif params["action"] == "listing_episodes":
            list_episodes(params['link'], params['id'], params['thumb'])
        elif params["action"] == "listing_menu_genres":
            list_menu_genres()
        elif params["action"] == "listing_genres":
            list_genres(params['link'], params["page"])
        elif params["action"] == "listing_years":
            list_years()
        elif params["action"] == "listing_search":
                search()
        elif params["action"] == "play":
            play_video(params['link'])
        elif params["action"] == "trailer":
            url = urlopen("https://api.themoviedb.org/3/" + params["type"] + "/" + params["yt_id"] + "?api_key=1f0150a5f78d4adc2407911989fdb66c&append_to_response=videos&language=cs-Cs").read()
            if json.loads(url)["videos"]["results"] == []:
                url1 = urlopen("https://api.themoviedb.org/3/" + params["type"] + "/" + params["yt_id"] + "?api_key=1f0150a5f78d4adc2407911989fdb66c&append_to_response=videos").read()
                if json.loads(url1)["videos"]["results"] != []:
                    key = json.loads(url1)["videos"]["results"][0]["key"]
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s)' %key)
                else:
                    xbmcgui.Dialog().notification("FelixTV","Nenalezeno", xbmcgui.NOTIFICATION_ERROR, 3000, sound = False)
            else:
                key = json.loads(url)["videos"]["results"][0]["key"]
                xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s)' %key)
        elif params["action"] == "library":
            if addon.getSetting("library") == "" or not os.path.exists(addon.getSetting("library")):
                xbmcgui.Dialog().notification("FelixTV","Nastavte složku pro knihovnu filmů", xbmcgui.NOTIFICATION_ERROR, 3000)
                return
            path = addon.getSetting("library") + (encode(params["name"].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))).replace(":", "").replace(" - CZ", "").replace(" - EN", "") + ".strm"
            f = open(path, "w")
            f.write("plugin://plugin.video.felixtv/?action=play&link=" + params['url'])
            f.close()
            xbmcgui.Dialog().notification("FelixTV","Uloženo", xbmcgui.NOTIFICATION_INFO, 3000, sound = False)
#xbmc.executebuiltin('XBMC.UpdateLibrary(video)')
        elif params["action"] == "library_series":
            if addon.getSetting("librarys") == "" or not os.path.exists(addon.getSetting("librarys")):
                xbmcgui.Dialog().notification("FelixTV","Nastavte složku pro knihovnu seriálů", xbmcgui.NOTIFICATION_ERROR, 3000)
                return
            path = addon.getSetting("librarys") + (encode(params["name"].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))).replace(":", "").replace(" - CZ", "").replace(" - EN", "") + "/"
            if not os.path.exists(path):
                os.makedirs(path)
            html = urlopen(params['url']).read()
            serial_list = []
            serial = []
            series=re.findall('<a data-toggle="tab" href="#s-(.*?)"',str(html))
            for s in series:
                episodes=re.findall('<div id="s-' + s + '(.*?)</div>',str(html), re.DOTALL)
                episodes=re.findall('href="(.*?)"',str(episodes), re.DOTALL)
                serial_list.append(("s" + str(series.index(s)+1), episodes))
            for x in serial_list:
                for y in x[1]:
                    serial.append((x[0] + "e" + str(x[1].index(y)+1) + ".strm", y))
            for st in serial:
                f = open(path + st[0], 'w')
                f.write("plugin://plugin.video.felixtv/?action=play&link=" + st[1])
                f.close()
            xbmcgui.Dialog().notification("FelixTV","Uloženo", xbmcgui.NOTIFICATION_INFO, 3000, sound = False)
        elif params["action"] == "download":
            download_video(params['url'], (encode(params["name"].encode().decode('unicode-escape').encode('latin1').decode('utf-8'))).replace(":", "").replace(" - CZ", "").replace(" - EN", ""))
#xbmc.executebuiltin('XBMC.UpdateLibrary(video)')
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])